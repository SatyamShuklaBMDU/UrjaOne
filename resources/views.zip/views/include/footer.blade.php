<div class="footer">
    <div class="copyright">
        <p>Copyright © Designed &amp; Developed by <a href="https://bmdu.net/" target="_blank">BMDU</a> 2024</p>
    </div>
</div>
